<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBa0Sd4XAj0758jPxU-9ZiuKSC0KEJ2yCg" async defer></script>
<script type='text/javascript'>
  //<![CDATA[
  window.onload = function() {
    var locations = [
      <?php
      foreach ($faskes as $key => $value) {
      ?>['<?php echo $value['nama_faskes']; ?>', <?php echo $value['latitude']; ?>, <?php echo $value['longitude']; ?>, '<?php echo $value['alamat']; ?>', '<?php echo $value['nomor_telpon']; ?>'],
      <?php
      }
      ?>
    ];
    var map;
    var markers = [];

    function init() {
      map = new google.maps.Map(document.getElementById('map_canvas'), {
        zoom: 12,
        center: new google.maps.LatLng(-6.21462, 106.84513),
        mapTypeId: google.maps.MapTypeId.ROADMAP
      });

      var num_markers = locations.length;
      for (var i = 0; i < num_markers; i++) {
        markers[i] = new google.maps.Marker({
          position: {
            lat: locations[i][1],
            lng: locations[i][2]
          },
          map: map,
          nama: locations[i][0],
          alamat: locations[i][3],
          telp: locations[i][4],
          id: i,
        });

        google.maps.event.addListener(markers[i], 'click', function() {
          var infowindow = new google.maps.InfoWindow({
            id: this.id,
            content: 'Nama : ' + this.nama + '<br>Alamat : ' + this.alamat + '<br>No. Telepon : ' + this.telp,
            position: this.getPosition()
          });
          google.maps.event.addListenerOnce(infowindow, 'closeclick', function() {
            markers[this.id].setVisible(true);
          });
          this.setVisible(false);
          infowindow.open(map);
        });
      }
    }

    init();
  } //]]> 
</script>
<style>
  #map_canvas {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
  }
</style>
<div id="map_canvas"></div>