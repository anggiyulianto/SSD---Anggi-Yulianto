<link rel="stylesheet" href="<?php echo base_url('assets/plugins/datepicker/datepicker3.css'); ?>">
<div class="content-wrapper">
  <section class="content-header">
    <h1>Faskes Input</h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url('faskes'); ?>"><i class="fa fa-home"></i> Faskes</a></li>
      <li class="active">Faskes Input</li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-success">
          <div class="box-header with-border">
          </div>
          <form class="form-horizontal" action="<?php echo base_url('faskes/input'); ?>" method="post">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Name Faskes</label>
                <div class="col-sm-10">
                  <input type="text" name="nama_faskes" class="form-control" required="required" placeholder="Name Faskes">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Alamat</label>
                <div class="col-sm-10">
                  <textarea class="form-control" name="alamat" rows="3" placeholder="Alamat" required="required"></textarea>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">No Telepon</label>
                <div class="col-sm-10">
                  <input type="text" name="nomor_telpon" class="form-control" required="required" placeholder="No Telepon">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">latitude</label>
                <div class="col-sm-10">
                  <input type="text" name="latitude" class="form-control" required="required" placeholder="latitude" onkeypress="validate(event)">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">longitude</label>
                <div class="col-sm-10">
                  <input type="text" name="longitude" class="form-control" required="required" placeholder="longitude" onkeypress="validate(event)">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Status</label>
                <div class="col-sm-10">
                  <select class="form-control select2" style="width: 100%;" name="active">
                    <option value="1">Active</option>
                    <option value="0">Not Active</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label"></label>
                <div class="col-sm-10">
                  <input type="submit" name="proses" class="btn btn-success" value="Submit">
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</div>

<script>
  function validate(evt) {
    var theEvent = evt || window.event;

    // Handle paste
    if (theEvent.type === 'paste') {
      key = event.clipboardData.getData('text/plain');
    } else {
      // Handle key press
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
    }
    var regex = /[-0-9]|\./;
    if (!regex.test(key)) {
      theEvent.returnValue = false;
      if (theEvent.preventDefault) theEvent.preventDefault();
    }
  }
</script>