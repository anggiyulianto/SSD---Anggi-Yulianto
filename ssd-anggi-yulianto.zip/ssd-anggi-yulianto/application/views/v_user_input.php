<link rel="stylesheet" href="<?php echo base_url('assets/plugins/datepicker/datepicker3.css'); ?>">
<div class="content-wrapper">
  <section class="content-header">
    <h1>User Input</h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url('user'); ?>"><i class="fa fa-home"></i> User Kategori</a></li>
      <li class="active">User Input</li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-success">
          <div class="box-header with-border">
          </div>
          <form class="form-horizontal" action="<?php echo base_url('user/input'); ?>" method="post">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">User Group</label>
                <div class="col-sm-10">
                  <select class="form-control" name="id_user_group" required>
                    <option value="">Please Select</option>
                    <?php
                    foreach ($user_group as $data) {
                    ?>
                      <option value="<?php echo $data['id_user_group'] ?>"><?php echo $data['nama_user_group'] ?></option>
                    <?php
                    }
                    ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                  <input type="text" name="username" class="form-control nama" required="required" placeholder="Username">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Password</label>
                <div class="col-sm-10">
                  <input type="password" name="password" class="form-control" required="required" placeholder="Password">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Password Ulangi</label>
                <div class="col-sm-10">
                  <input type="password" name="password2" class="form-control" required="required" placeholder="Password Ulangi">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Status</label>
                <div class="col-sm-10">
                  <select class="form-control select2" style="width: 100%;" name="active" required="required">
                    <option value="1">Active</option>
                    <option value="0">Not Active</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label"></label>
                <div class="col-sm-10">
                  <input type="submit" name="proses" class="btn btn-success" value="Submit">
                </div>
              </div>

            </div>
          </form>

        </div>
      </div>
    </div>
  </section>
</div>
<script src="<?php echo base_url('assets/plugins/datepicker/bootstrap-datepicker.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/input-mask/jquery.inputmask.bundle.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/chain/jquery.chained.min.js') ?>"></script>
<script>
  $(function() {
    $(".nama").on('input', function(evt) {
      var input = $(this);
      var start = input[0].selectionStart;
      $(this).val(function(_, val) {
        return val.toUpperCase();
      });
      input[0].selectionStart = input[0].selectionEnd = start;
    });

  });
</script>