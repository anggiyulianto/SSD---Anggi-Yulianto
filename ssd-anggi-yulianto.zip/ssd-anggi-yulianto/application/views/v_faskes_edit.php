<link rel="stylesheet" href="<?php echo base_url('assets/plugins/datepicker/datepicker3.css'); ?>">
<div class="content-wrapper">
  <section class="content-header">
    <h1>Faskes Edit</h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url('faskes'); ?>"><i class="fa fa-home"></i> Faskes</a></li>
      <li class="active">Faskes Edit</li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-success">
          <div class="box-header with-border">
          </div>
          <form class="form-horizontal" action="<?php echo base_url('faskes/edit'); ?>" method="post">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Name Faskes</label>
                <div class="col-sm-10">
                  <input type="hidden" name="id_faskes" class="form-control nama" required="required" value="<?php echo $faskes->id_faskes; ?>" readonly>
                  <input type="text" name="nama_faskes" class="form-control nama" required="required" placeholder="Name Faskes" value="<?php echo $faskes->nama_faskes; ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Alamat</label>
                <div class="col-sm-10">
                  <textarea class="form-control" name="alamat" rows="3" placeholder="Alamat" required="required"><?php echo $faskes->alamat; ?></textarea>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">No Telepon</label>
                <div class="col-sm-10">
                  <input type="text" name="nomor_telpon" class="form-control" required="required" placeholder="No Telepon" value="<?php echo $faskes->nomor_telpon; ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">latitude</label>
                <div class="col-sm-10">
                  <input type="text" name="latitude" class="form-control" required="required" placeholder="latitude" value="<?php echo $faskes->latitude; ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">longitude</label>
                <div class="col-sm-10">
                  <input type="text" name="longitude" class="form-control" required="required" placeholder="longitude" value="<?php echo $faskes->longitude; ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Status</label>
                <div class="col-sm-10">
                  <select class="form-control select2" style="width: 100%;" name="active">
                    <option value="1" <?php echo $faskes->active == 1 ? "selected" : ""; ?>>Active</option>
                    <option value="0" <?php echo $faskes->active == 0 ? "selected" : ""; ?>>Not Active</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label"></label>
                <div class="col-sm-10">
                  <input type="submit" name="proses" class="btn btn-success" value="Submit">
                </div>
              </div>

            </div>
          </form>

        </div>
      </div>
    </div>
  </section>
</div>