<link rel="stylesheet" href="<?php echo base_url('assets/plugins/datepicker/datepicker3.css'); ?>">
<div class="content-wrapper">
    <section class="content-header">
      <h1>menu Edit</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('menu'); ?>"><i class="fa fa-home"></i> menu</a></li>
        <li class="active">menu Edit</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-success">
            <div class="box-header with-border">
            </div>
            <form class="form-horizontal" action="<?php echo base_url('menu/edit'); ?>" method="post">
              <div class="box-body"> 
                <div class="form-group">
                  <label class="col-sm-2 control-label">Menu Header</label>
                  <div class="col-sm-10">
                    <input type="hidden" name="id_menu" class="form-control" required  value="<?php echo $menu->id_menu; ?>">
                    <select class="form-control select2" style="width: 100%;" name="parent_menu_id">
                      <option value="1" <?php echo $menu->parent_menu_id == 1 ? "selected" : ""; ?>>MASTER DATA</option>   
                      <option value="2" <?php echo $menu->parent_menu_id == 2 ? "selected" : ""; ?>>TRANSACTION</option>   
                      <option value="3" <?php echo $menu->parent_menu_id == 3 ? "selected" : ""; ?>>REPORT</option>     
                      <option value="3" <?php echo $menu->parent_menu_id == 4 ? "selected" : ""; ?>>SYSTEM</option>   
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Nama Menu</label>
                  <div class="col-sm-10">
                    <input type="text" name="nama_menu" class="form-control" required placeholder="Nama Menu"  value="<?php echo $menu->nama_menu; ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Urut</label>
                  <div class="col-sm-10">
                    <input type="text" name="urut" class="form-control angka" required placeholder="Urut"  value="<?php echo $menu->urut; ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Status</label>
                  <div class="col-sm-10">
                      <select class="form-control select2" style="width: 100%;" name="active">
                        <option value="1" <?php echo $menu->active == 1 ? "selected" : ""; ?>>Active</option>   
                        <option value="0" <?php echo $menu->active == 0 ? "selected" : ""; ?>>Not Active</option>   
                      </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="proses" class="btn btn-success" value="Submit">
                  </div>
                </div>
        
              </div>
            </form>
            
          </div>
        </div>
      </div>
    </section>
  </div>
<script src="<?php echo base_url('assets/plugins/input-mask/inputmask.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/input-mask/inputmask.numeric.extensions.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/input-mask/jquery.inputmask.js'); ?>"></script>
<script>
  $("#city").chained("#province");
  $(function () {
     $('.angka').inputmask("numeric", {
      radixPoint: "",
      groupSeparator: "",
      digits: 2,
      autoGroup: true,
      // prefix: 'Rp ',
      rightAlign: false,
      oncleared: function () { self.Value(''); }
    });

    $(".nama").on('input', function(evt) {
      var input = $(this);
      var start = input[0].selectionStart;
      $(this).val(function (_, val) {
        return val.toUpperCase();
      });
      input[0].selectionStart = input[0].selectionEnd = start;
    });

    $(".huruf").keypress(function(event) {
      var charCode = (event.which) ? event.which : event.keyCode
      if ((charCode >= 65 && charCode <= 90)||(charCode >= 97 && charCode <= 122))
      return true;
      return false;
    });

  });
</script>