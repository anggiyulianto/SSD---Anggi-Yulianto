<div class="content-wrapper">
  <section class="content-header">
    <h1>Profile User</h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url('home'); ?>"><i class="fa fa-home"></i> Home</a></li>
      <li class="active">Profile User</li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-success">
          <div class="box-header with-border">
          </div>
          <form class="form-horizontal" action="<?php echo base_url('profile/edit'); ?>" method="post">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                  <input type="hidden" name="id_user" class="form-control" required="required" value="<?php echo $user->id_user; ?>" readonly>
                  <input type="text" name="username" class="form-control" required="required" placeholder="Name user" value="<?php echo $user->username; ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">No Telepon</label>
                <div class="col-sm-10">
                  <input type="text" name="phone_number" class="form-control" required="required" placeholder="No Telepon" value="<?php echo $user->phone_number; ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">New Password</label>
                <div class="col-sm-10">
                  <input type="password" name="new" class="form-control" placeholder="New Password">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Re-type new</label>
                <div class="col-sm-10">
                  <input type="password" name="renew" class="form-control" placeholder="Re-type New Password">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label"></label>
                <div class="col-sm-10">
                  <input type="submit" name="proses" class="btn btn-success" value="Update" />
                </div>
              </div>

            </div>
          </form>

        </div>
      </div>
    </div>
  </section>
</div>