<link rel="stylesheet" href="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.css'); ?>">
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Menu List</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('home'); ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Menu List</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header"></div>
        			<p align="right" style="padding-right:10px">
        			</p>
            <div class="box-body">
            <div class="table-responsive">
              <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th style="width:5px">No</th>
                  <th>Header Menu</th>
                  <th>Nama Menu</th>
                  <th>Urut</th>
                  <th>Status</th>
                  <th>Action</th>
                </thead>
                <tbody>
                <?php
                  $no=1;
                  foreach ($menu as $data) {
                ?>
                  <tr>
                    <td><?php echo $no; ?></td>
                    <td><?php echo $data['parent_nama']; ?></td>
                    <td><?php echo $data['nama_menu']; ?></td>
                    <td><?php echo $data['urut']; ?></td>
                    <td><?php echo $data['active'] == 1 ? "<font color='#0f0'>Active</font>" : "<font color='#f00'>Not Active</font>"; ?></td>
                    <td>
                      <a href="<?php echo base_url('menu/edit/'.base64_encode($data['id_menu'])); ?>"><span><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit </span></a>
                      | 
                      <a href="<?php echo base_url('menu/active/'.base64_encode($data['id_menu']).'/'.$data['active']); ?>" onclick="return confirm('are you sure you want to update this ?')"><span><i class="fa fa-exchange" aria-hidden="true"></i> <?php echo $data['active'] == 1 ? "Deactivate" : "Reactivate"; ?> </span></a>
                    </td>
                  </tr>
                <?php
                  $no++;
                  }
                ?>  
                </tbody>
              </table>
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <div class="control-sidebar-bg"></div>
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js'); ?>"></script>
<script>
  $(function () {
    $("#example1").DataTable();
  });
</script>  