<?php
if (get_cookie('status') != "loginuser") {
  redirect('login');
}
$setting = $this->m_setting->data();
$menu_master = $this->m_menu->data_master()->result_array();
$menu_transaksi = $this->m_menu->data_transaksi()->result_array();
$menu_report = $this->m_menu->data_report()->result_array();
$menu_system = $this->m_menu->data_system()->result_array();
$id_user = get_cookie('id_user');
$user = $this->m_user->data_by_id(array('id_user' => $id_user))->row();
if ($user->active == 0) {
  delete_cookie('id_user');
  delete_cookie('username');
  delete_cookie('status');
  echo "<script>alert('User is Not Activated, Please Contact Your Administrator');window.location.href='login';</script>";
}
$id_user_group = $user->id_user_group;
$user_group = $this->m_user_group->data_by_id(array('id_user_group' => $id_user_group))->row();
$data_user_group = explode(',', $user_group->menu);
$id = $this->uri->segment(1);
if ($id != 'home') {
  $menu = $this->m_menu->data_by_id("controller='$id'")->row();
  if ($menu->active == 0) {
    delete_cookie('id_user');
    delete_cookie('username');
    delete_cookie('status');
    echo "<script>alert('This Menu is Not Activated, Please Contact Your Administrator');window.location.href='login';</script>";
  }
  if (!in_array($menu->id_menu, $data_user_group)) {
    delete_cookie('id_user');
    delete_cookie('username');
    delete_cookie('status');
    echo "<script>alert('You are not authorized to access this menu');window.location.href='login';</script>";
  }
}
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $setting->nama_program; ?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/select2.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/AdminLTE.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/skins/_all-skins.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/plugins/iCheck/flat/blue.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/plugins/jvectormap/jquery-jvectormap-1.2.2.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/plugins/datepicker/datepicker3.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/plugins/daterangepicker/daterangepicker.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css'); ?>">
  <script src="<?php echo base_url('assets/plugins/jQuery/jquery-2.2.3.min.js'); ?>"></script>
</head>

<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    <header class="main-header">
      <a href="<?php echo base_url('home'); ?>" class="logo" style="background-color: #<?php echo $setting->color_program; ?>">
        <span class="logo-mini"><b>A</b>Y</span>
        <span class="logo-lg"><b><?php echo $setting->nama_program; ?></b></span>
      </a>
      <nav class="navbar navbar-static-top" style="background-color: #<?php echo $setting->color_program; ?>">
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button" style="background-color: #<?php echo $setting->color_program; ?>">
          <span class="sr-only">Toggle navigation</span>
        </a>

        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <li class="dropdown user user-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <img src="<?php echo base_url('assets/images/user.png'); ?>" class="user-image" alt="User Image">
                <span class="hidden-xs"><?php echo ucwords(strtolower(get_cookie('username'))); ?></span>
              </a>
              <ul class="dropdown-menu">
                <li class="user-header" style="background-color: #<?php echo $setting->color_program; ?>">
                  <img src="<?php echo base_url('assets/images/user.png'); ?>" class="img-circle" alt="User Image">
                  <p>
                    <small>Username: <?php echo get_cookie('username'); ?></small>
                  </p>
                </li>
                <li class="user-footer">
                  <div class="pull-left">
                    <a href="<?php echo base_url('user/password'); ?>" class="btn btn-default btn-flat">Change Password</a>
                  </div>
                  <div class="pull-right">
                    <a href="<?php echo base_url('login/logout'); ?>" class="btn btn-default btn-flat">Sign out</a>
                  </div>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <aside class="main-sidebar">
      <section class="sidebar">
        <div class="user-panel">
          <div class="pull-left image">
            <img src="<?php echo base_url('assets/images/user.png'); ?>" class="img-circle" alt="User Image">
          </div>
          <div class="pull-left info">
            <p><?php echo ucwords(strtolower(get_cookie('username'))); ?></p>
            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
          </div>
        </div>
        <ul class="sidebar-menu">
          <li class="header">MAIN NAVIGATION</li>

          <li>
            <a href="<?php echo base_url('home'); ?>">
              <i class="fa fa-dashboard"></i> <span>Home</span>
            </a>
          </li>
          <li class="treeview">
            <a href="#">
              <i class="fa fa-th"></i> <span>Master Data</span>
              <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
            </a>
            <ul class="treeview-menu">
              <?php
              foreach ($menu_master as $data) {
                if (in_array($data['id_menu'], $data_user_group)) {
              ?>
                  <li><a href="<?php echo base_url($data['controller']); ?>"><i class="fa fa-circle-o"></i> <?php echo $data['nama_menu']; ?></a></li>
              <?php
                }
              }
              ?>
            </ul>
          </li>
          <li class="treeview">
            <a href="#">
              <i class="fa fa-inbox"></i> <span>System</span>
              <span class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
            </a>
            <ul class="treeview-menu">
              <?php
              foreach ($menu_system as $data) {
                if (in_array($data['id_menu'], $data_user_group)) {
              ?>
                  <li><a href="<?php echo base_url($data['controller']); ?>"><i class="fa fa-circle-o"></i> <?php echo $data['nama_menu']; ?></a></li>
              <?php
                }
              }
              ?>
            </ul>
          </li>
        </ul>
      </section>
    </aside>

    <?php $this->load->view($content); ?>

    <footer class="main-footer">
      <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
      </div>
      <strong>Copyright &copy; 2021 <a href="#" style="color: #<?php echo $setting->color_program; ?>"><?php echo $setting->nama_program; ?></a>.</strong> All rights reserved.
    </footer>
    <div class="control-sidebar-bg"></div>
  </div>
  <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
  <script>
    $(function() {
      $('.select2').select2()
    });
    $.widget.bridge('uibutton', $.ui.button);
    $(function() {
      $(".nama").on('input', function(evt) {
        var input = $(this);
        var start = input[0].selectionStart;
        $(this).val(function(_, val) {
          return val.toUpperCase();
        });
        input[0].selectionStart = input[0].selectionEnd = start;
      });

    });
  </script>
  <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
  <script src="<?php echo base_url('assets/plugins/sparkline/jquery.sparkline.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js'); ?>"></script>
  <script src="<?php echo base_url('assets/plugins/knob/jquery.knob.js'); ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
  <script src="<?php echo base_url('assets/plugins/daterangepicker/daterangepicker.js'); ?>"></script>
  <script src="<?php echo base_url('assets/plugins/datepicker/bootstrap-datepicker.js'); ?>"></script>
  <script src="<?php echo base_url('assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/plugins/slimScroll/jquery.slimscroll.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/plugins/fastclick/fastclick.js'); ?>"></script>
  <script src="<?php echo base_url('assets/dist/js/app.min.js'); ?>"></script>
  <!-- <script src="<?php //echo base_url('assets/dist/js/pages/dashboard.js'); 
                    ?>"></script> -->
  <script src="<?php echo base_url('assets/dist/js/select2.full.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/dist/js/demo.js'); ?>"></script>
</body>

</html>