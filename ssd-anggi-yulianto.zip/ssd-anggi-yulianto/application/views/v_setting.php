<link rel="stylesheet" href="<?php echo base_url('assets/plugins/datepicker/datepicker3.css'); ?>">
<div class="content-wrapper">
    <section class="content-header">
      <h1>Setting System</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('home'); ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Setting System</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-success">
            <div class="box-header with-border">
            </div>
            <form class="form-horizontal" action="<?php echo base_url('setting/index'); ?>" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label class="col-sm-2 control-label">Nama Program</label>
                  <div class="col-sm-10">
                    <input type="text" name="nama_program" class="form-control nama"  required="required" placeholder="Nama Program" value="<?php echo $setting->nama_program; ?>" maxlength="30">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Color Program</label>
                  <div class="col-sm-10">
                    <input type="text" name="color_program" class="form-control nama jscolor"  required="required" value="<?php echo $setting->color_program; ?>" readonly>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <input type="submit" name="proses" class="btn btn-success" value="Submit">
                  </div>
                </div>
        
              </div>
            </form>
            
          </div>
        </div>
      </div>
    </section>
  </div>
<script src="<?php echo base_url('assets/plugins/input-mask/inputmask.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/input-mask/inputmask.numeric.extensions.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/input-mask/jquery.inputmask.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/jscolor/jscolor.js') ?>"></script>

<script>
  $(function () {
     $('.angka').inputmask("numeric", {
      radixPoint: ",",
      groupSeparator: ".",
      digits: 2,
      autoGroup: true,
      // prefix: 'Rp ',
      rightAlign: false,
      oncleared: function () { self.Value(''); }
    });
    $(".nama").on('input', function(evt) {
      var input = $(this);
      var start = input[0].selectionStart;
      $(this).val(function (_, val) {
        return val.toUpperCase();
      });
      input[0].selectionStart = input[0].selectionEnd = start;
    });

  });
</script>