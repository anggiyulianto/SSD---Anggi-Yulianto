  <style>
    #map {
      height: 100%;
    }

    html,
    body {
      height: 100%;
      margin: 0;
      padding: 0;
    }

    #info-box {
      background-color: white;
      border: 1px solid black;
      bottom: 30px;
      height: 20px;
      padding: 10px;
      position: absolute;
      left: 30px;
    }

    #menu {
      position: absolute;
      height: 100px;
    }

    #menu {
      width: 100px;
      left: 10px;
      top: 60px;
      z-index: 1;

    }
  </style>
  <link rel="stylesheet" href="https://www.codehim.com/demo/bootstrap-multiselect-dropdown/docs/css/bootstrap-3.3.2.min.css" type="text/css" />
  <script type="text/javascript" src="https://www.codehim.com/demo/bootstrap-multiselect-dropdown/docs/js/jquery-2.1.3.min.js"></script>
  <script type="text/javascript" src="https://www.codehim.com/demo/bootstrap-multiselect-dropdown/docs/js/bootstrap-3.3.2.min.js"></script>

  <script type="text/javascript" src="https://www.codehim.com/demo/bootstrap-multiselect-dropdown/dist/js/bootstrap-multiselect.js"></script>
  <link rel="stylesheet" href="https://www.codehim.com/demo/bootstrap-multiselect-dropdown/dist/css/bootstrap-multiselect.css" type="text/css" />
  <div id="menu">
    <div class="example">
      <script type="text/javascript">
        $(document).ready(function() {
          var aa;
          $('#example-enableCollapsibleOptGroups-collapsed').multiselect({
            maxHeight: 200,
            enableClickableOptGroups: true,
            enableCollapsibleOptGroups: true,
            buttonContainer: '<div id="example-enableCollapsibleOptGroups-collapsed-container" />',
            onChange: function(option, checked) {
              var data = $('select#example-enableCollapsibleOptGroups-collapsed').val();
              if (data == null) {
                initMap();
              } else if (data == 'FASKES') {
                initMapfaskes();
              } else if (data == 'KELURAHAN') {
                initMapkelurahan();
              } else {
                alert('silakan pilih salah satu');
              }
            }
          });
          $('#example-enableCollapsibleOptGroups-collapsed-container .caret-container').click();
        });
      </script>
      <select id="example-enableCollapsibleOptGroups-collapsed" multiple="multiple">
        <optgroup label="FASKES">
          <option value="FASKES">All</option>
        </optgroup>
        <optgroup label="KELURAHAN">
          <option value="KELURAHAN">All</option>
        </optgroup>
      </select>
    </div>

  </div>
  <div id="map"></div>
  <script>
    var map;

    function initMap() {
      map = new google.maps.Map(document.getElementById('map'), {
        zoom: 12,
        center: {
          lat: -6.21462,
          lng: 106.84513
        }
      });

    }

    function initMapkelurahan() {
      map = new google.maps.Map(document.getElementById('map'), {
        zoom: 12,
        center: {
          lat: -6.21462,
          lng: 106.84513
        }
      });

      map.data.loadGeoJson(
        '<?php echo base_url('api/get_kelurahan');
          ?>'
      );

      map.data.setStyle({
        fillColor: 'green',
        strokeWeight: 1
      });

      var infowindow = new google.maps.InfoWindow();

      map.data.addListener('click', function(event) {
        let nama_provinsi = event.feature.getProperty("nama_provinsi");
        let kode_kota = event.feature.getProperty("kode_kota");
        let nama_kota = event.feature.getProperty("nama_kota");
        let kode_kecamatan = event.feature.getProperty("kode_kecamatan");
        let nama_kecamatan = event.feature.getProperty("nama_kecamatan");
        let kode_kelurahan = event.feature.getProperty("kode_kelurahan");
        let nama_kelurahan = event.feature.getProperty("nama_kelurahan");
        let html = 'Nama Provinsi : ' + nama_provinsi + ' <br> Kode Kota : ' + kode_kota + ' <br> Nama Kota : ' + nama_kota + ' <br> Kode Kecamatan : ' + kode_kecamatan + ' <br> Nama Kecamatan : ' + nama_kecamatan + ' <br> Kode Kelurahan : ' + kode_kelurahan + ' <br> Nama Kelurahan : ' + nama_kelurahan;
        infowindow.setContent(html);
        infowindow.setPosition(event.latLng);
        infowindow.setOptions({
          pixelOffset: new google.maps.Size(0, -30)
        });
        infowindow.open(map);
      });

    }


    function initMapfaskes() {

      var locations = [
        <?php
        foreach ($faskes as $key => $value) {
        ?>['<?php echo $value['nama_faskes']; ?>', <?php echo $value['latitude']; ?>, <?php echo $value['longitude']; ?>, '<?php echo $value['alamat']; ?>', '<?php echo $value['nomor_telpon']; ?>'],
        <?php
        }
        ?>
      ];
      // var map;
      var markers = [];
      map = new google.maps.Map(document.getElementById('map'), {
        zoom: 12,
        center: new google.maps.LatLng(-6.21462, 106.84513),
        mapTypeId: google.maps.MapTypeId.ROADMAP
      });

      var num_markers = locations.length;
      for (var i = 0; i < num_markers; i++) {
        markers[i] = new google.maps.Marker({
          position: {
            lat: locations[i][1],
            lng: locations[i][2]
          },
          map: map,
          nama: locations[i][0],
          alamat: locations[i][3],
          telp: locations[i][4],
          id: i,
        });

        google.maps.event.addListener(markers[i], 'click', function() {
          var infowindow = new google.maps.InfoWindow({
            id: this.id,
            content: 'Nama : ' + this.nama + '<br>Alamat : ' + this.alamat + '<br>No. Telepon : ' + this.telp,
            position: this.getPosition()
          });
          google.maps.event.addListenerOnce(infowindow, 'closeclick', function() {
            markers[this.id].setVisible(true);
          });
          this.setVisible(false);
          infowindow.open(map);
        });
      }
    }
  </script>
  <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBa0Sd4XAj0758jPxU-9ZiuKSC0KEJ2yCg&callback=initMap"></script>