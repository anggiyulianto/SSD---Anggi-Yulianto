  <style>
    #map {
      height: 100%;
    }

    html,
    body {
      height: 100%;
      margin: 0;
      padding: 0;
    }

    #info-box {
      background-color: white;
      border: 1px solid black;
      bottom: 30px;
      height: 20px;
      padding: 10px;
      position: absolute;
      left: 30px;
    }
  </style>

  <div id="map"></div>
  <script>
    var map;

    function initMap() {
      map = new google.maps.Map(document.getElementById('map'), {
        zoom: 12,
        center: {
          lat: -6.21462,
          lng: 106.84513
        }
      });

      map.data.loadGeoJson(
        '<?php echo base_url('api/get_kelurahan'); ?>'
      );

      map.data.setStyle({
        fillColor: 'green',
        strokeWeight: 1
      });

      var infowindow = new google.maps.InfoWindow();

      map.data.addListener('click', function(event) {
        let nama_provinsi = event.feature.getProperty("nama_provinsi");
        let kode_kota = event.feature.getProperty("kode_kota");
        let nama_kota = event.feature.getProperty("nama_kota");
        let kode_kecamatan = event.feature.getProperty("kode_kecamatan");
        let nama_kecamatan = event.feature.getProperty("nama_kecamatan");
        let kode_kelurahan = event.feature.getProperty("kode_kelurahan");
        let nama_kelurahan = event.feature.getProperty("nama_kelurahan");
        let html = 'Nama Provinsi : ' + nama_provinsi + ' <br> Kode Kota : ' + kode_kota + ' <br> Nama Kota : ' + nama_kota + ' <br> Kode Kecamatan : ' + kode_kecamatan + ' <br> Nama Kecamatan : ' + nama_kecamatan + ' <br> Kode Kelurahan : ' + kode_kelurahan + ' <br> Nama Kelurahan : ' + nama_kelurahan;
        infowindow.setContent(html);
        infowindow.setPosition(event.latLng);
        infowindow.setOptions({
          pixelOffset: new google.maps.Size(0, -30)
        });
        infowindow.open(map);
      });

    }
  </script>
  <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBa0Sd4XAj0758jPxU-9ZiuKSC0KEJ2yCg&callback=initMap">
  </script>