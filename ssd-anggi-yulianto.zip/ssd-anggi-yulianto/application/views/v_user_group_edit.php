<link rel="stylesheet" href="<?php echo base_url('assets/plugins/datepicker/datepicker3.css'); ?>">
<div class="content-wrapper">
  <section class="content-header">
    <h1>User Group Edit</h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url('user_group'); ?>"><i class="fa fa-home"></i> User Group</a></li>
      <li class="active">User Group Edit</li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box box-success">
          <div class="box-header with-border">
          </div>
          <form class="form-horizontal" action="<?php echo base_url('user_group/edit'); ?>" method="post">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Kode User Group</label>
                <div class="col-sm-10">
                  <input type="hidden" name="id_user_group" class="form-control nama" required="required" value="<?php echo $user_group->id_user_group; ?>" readonly>
                  <input type="text" name="kode_user_group" class="form-control nama" required="required" placeholder="Kode User Group" value="<?php echo $user_group->kode_user_group; ?>" readonly>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">User Group Name</label>
                <div class="col-sm-10">
                  <input type="text" name="nama_user_group" class="form-control nama" required="required" placeholder="Nama User Group" value="<?php echo $user_group->nama_user_group; ?>">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Menu Master</label>
                <div class="col-sm-10">
                  <div class="form-group" style="margin-left: 5px;">
                    <?php
                    foreach ($menu_master as $data) {
                    ?>
                      <div class="checkbox">
                        <label>
                          <input type="checkbox" <?php echo (in_array($data['id_menu'], $user_group_menu) ? 'checked' : ''); ?> name="menu[]" value="<?php echo $data['id_menu']; ?>"> <?php echo $data['nama_menu']; ?> </label>
                      </div>
                    <?php
                    }
                    ?>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Menu System</label>
                <div class="col-sm-10">
                  <div class="form-group" style="margin-left: 5px;">
                    <?php
                    foreach ($menu_system as $data) {
                    ?>
                      <div class="checkbox">
                        <label> <input type="checkbox" <?php echo (in_array($data['id_menu'], $user_group_menu) ? 'checked' : ''); ?> name="menu[]" value="<?php echo $data['id_menu']; ?>"> <?php echo $data['nama_menu']; ?> </label>
                      </div>
                    <?php
                    }
                    ?>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Status</label>
                <div class="col-sm-10">
                  <select class="form-control select2" style="width: 100%;" name="active">
                    <option value="1" <?php echo $user_group->active == 1 ? "selected" : ""; ?>>Active</option>
                    <option value="0" <?php echo $user_group->active == 0 ? "selected" : ""; ?>>Not Active</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label"></label>
                <div class="col-sm-10">
                  <input type="submit" name="proses" class="btn btn-success" value="Submit">
                </div>
              </div>

            </div>
          </form>

        </div>
      </div>
    </div>
  </section>
</div>
<script src="<?php echo base_url('assets/plugins/datepicker/bootstrap-datepicker.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/input-mask/jquery.inputmask.bundle.js'); ?>"></script>
<script src="<?php echo base_url('assets/plugins/chain/jquery.chained.min.js') ?>"></script>
<script>
  $("#city").chained("#province");
  $(function() {
    $('#salary').inputmask("numeric", {
      radixPoint: ",",
      groupSeparator: ".",
      digits: 2,
      autoGroup: true,
      // prefix: 'Rp ',
      rightAlign: false,
      oncleared: function() {
        self.Value('');
      }
    });

    $('#datepicker').datepicker({
      autoclose: true
    });

    $(".nama").on('input', function(evt) {
      var input = $(this);
      var start = input[0].selectionStart;
      $(this).val(function(_, val) {
        return val.toUpperCase();
      });
      input[0].selectionStart = input[0].selectionEnd = start;
    });

    $(".huruf").keypress(function(event) {
      var charCode = (event.which) ? event.which : event.keyCode
      if ((charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122))
        return true;
      return false;
    });

  });
</script>