  <div class="content-wrapper">
    <section class="content-header">
      <h1> Dashboard </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <section class="content">
      <div class="row">

        <!--<div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $produk_kategori; ?></h3>
              <p>Kategori Produk</p>
            </div>
            <div class="icon">
              <i class="fa fa-server"></i>
            </div>
            <a href="<?php echo base_url('produk_kategori'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $produk; ?></h3>
              <p>Produk</p>
            </div>
            <div class="icon">
              <i class="fa fa-server "></i>
            </div>
            <a href="<?php echo base_url('produk'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo number_format($gudang->stok, 0 , '' , '.' ); ?></h3>
              <p>Stok Barang</p>
            </div>
            <div class="icon">
              <i class="fa fa-server"></i>
            </div>
            <a href="<?php echo base_url('gudang'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        -->
       <!--  <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php //echo $user; ?></h3>
              <p>User</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <a href="<?php //echo base_url('user'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php //echo $depresiasi; ?></h3>
              <p>Depresiasi</p>
            </div>
            <div class="icon">
              <i class="fa fa-hourglass-start"></i>
            </div>
            <a href="<?php //echo base_url('depresiasi'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php //echo $asset; ?></h3>
              <p>Asset</p>
            </div>
            <div class="icon">
              <i class="fa fa-inbox "></i>
            </div>
            <a href="<?php //echo base_url('asset'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php //echo $vendor; ?></h3>
              <p>Vendor</p>
            </div>
            <div class="icon">
              <i class="fa fa-exchange"></i>
            </div>
            <a href="<?php //echo base_url('vendor'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php //echo $material; ?></h3>
              <p>Material</p>
            </div>
            <div class="icon">
              <i class="fa fa-dropbox"></i>
            </div>
            <a href="<?php //echo base_url('material'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php //echo $product; ?></h3>
              <p>Product</p>
            </div>
            <div class="icon">
              <i class="fa fa-building-o"></i>
            </div>
            <a href="<?php //echo base_url('product'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php //echo $product_temp; ?></h3>
              <p>Product Template</p>
            </div>
            <div class="icon">
              <i class="fa fa-database"></i>
            </div>
            <a href="<?php //echo base_url('product_temp'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
 -->
      </div>
    </section>
  </div>