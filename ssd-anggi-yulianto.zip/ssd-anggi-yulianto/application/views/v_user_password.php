<div class="content-wrapper">
    <section class="content-header">
      <h1>Change Password</h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url('home'); ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Change Password</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-success">
            <div class="box-header with-border">
            </div>
             <form class="form-horizontal" action="<?php echo base_url('user/password'); ?>" method="post">
              <div class="box-body">        
                <div class="form-group">
                  <label class="col-sm-2 control-label">Current</label>
                  <div class="col-sm-10">
                    <input type="hidden" name="id_user" class="form-control" readonly value="<?php echo get_cookie('id_user'); ?>">
                    <input type="password" name="current" class="form-control" placeholder="Current Password">
                  </div>
                </div>        
        
                <div class="form-group">
                  <label class="col-sm-2 control-label">New</label>
                  <div class="col-sm-10">
                     <input type="password" name="new" class="form-control" placeholder="New Password">
                  </div>
                </div>        
        
                <div class="form-group">
                  <label class="col-sm-2 control-label">Re-type new</label>
                  <div class="col-sm-10">             
                     <input type="password" name="renew" class="form-control" placeholder="Re-type New Password">
                  </div>
                </div>
        
                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                     <input type="submit" name="proses" class="btn btn-success" value="Update" />
                  </div>
                </div>
        
              </div>
            </form>
            
          </div>
        </div>
      </div>
    </section>
  </div>