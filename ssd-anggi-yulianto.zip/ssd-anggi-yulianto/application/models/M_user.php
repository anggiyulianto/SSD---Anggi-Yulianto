<?php
class M_user extends CI_Model{
	public function __construct(){
		parent::__construct();
		$this->table = 'tbl_user';
	}
	
	function data(){
		$this->db->select('*');
		$this->db->from($this->table);	
		$this->db->where('deleted', 0);
		$this->db->order_by('username', 'asc');
		$query = $this->db->get();
		return $query;
	}
	
	function data_active(){
		$this->db->select('*');
		$this->db->from($this->table);	
		$this->db->where('deleted', 0);
		$this->db->where('active', 1);
		$this->db->order_by('username', 'asc');
		$query = $this->db->get();
		return $query;
	}

	function data_by_id($where){
		$data = $this->db->get_where($this->table, $where); 
		return $data;
	}

	function input_data($data){
		$this->db->insert($this->table, $data);
	}
	function update_data($where, $data){		
		$this->db->where($where);
		$this->db->update($this->table, $data);
	}
	
	function hapus_data($where, $data){		
		$this->db->where($where);
		$this->db->update($this->table, $data);
	}

	// function hapus_data($where){
	// 	$this->db->where($where);
	// 	$this->db->delete($this->table);
	// }
}