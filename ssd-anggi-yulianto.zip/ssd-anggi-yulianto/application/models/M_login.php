<?php
class M_login extends CI_Model{
	function loginuser($where){		
		$data = $this->db->get_where('tbl_user', $where); 
		return $data;
	}
	function data_by_id($where){
		$data = $this->db->get_where('tbl_user', $where); 
		return $data;
	}

}