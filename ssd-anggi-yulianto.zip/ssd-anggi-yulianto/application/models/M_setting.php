<?php
class M_setting extends CI_Model{
	public function __construct(){
		parent::__construct();
		$this->table = 'tbl_setting';
	}

	function data(){
		$this->db->select('*');
		$this->db->from($this->table);	
		$this->db->where('id_setting', 0);
		$query = $this->db->get()->row();
		return $query;
	}

	function update_data($data){
		$where = array('id_setting' => 0);	
		$this->db->where($where);
		$this->db->update($this->table, $data);
	}
	
}