<?php
class M_counter extends CI_Model{
	public function __construct(){
		parent::__construct();
		$this->table = 'tbl_counter';
	}
	
	function data_by_id($where){
		$data = $this->db->get_where($this->table, $where); 
		return $data;
	}

	function input_data($data){
		$this->db->insert($this->table, $data);
	}

	function update_data($where, $data){		
		$this->db->where($where);
		$this->db->update($this->table, $data);
	}

}