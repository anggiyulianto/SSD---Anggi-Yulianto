<?php
class M_menu extends CI_Model{
	public function __construct(){
		parent::__construct();
		$this->table = 'tbl_menu';
	}
	
	function data(){
		$this->db->select('*');
		$this->db->from($this->table);	
		$this->db->order_by('parent_menu_id', 'asc');
		$this->db->order_by('urut', 'asc');
		$this->db->order_by('nama_menu', 'asc');
		$query = $this->db->get();
		return $query;
	}

	function data_by_id($where){
		$data = $this->db->get_where($this->table, $where); 
		return $data;
	}

	function data_master(){
		$this->db->select('*');
		$this->db->from($this->table);	
		$this->db->where('active', 1);
		$this->db->where('parent_menu_id', 1);
		$this->db->order_by('urut', 'asc');
		$query = $this->db->get();
		return $query;
	}

	function data_transaksi(){
		$this->db->select('*');
		$this->db->from($this->table);	
		$this->db->where('active', 1);	
		$this->db->where('parent_menu_id', 2);
		$this->db->order_by('urut', 'asc');
		$query = $this->db->get();
		return $query;
	}

	function data_report(){
		$this->db->select('*');
		$this->db->from($this->table);	
		$this->db->where('active', 1);
		$this->db->where('parent_menu_id', 3);
		$this->db->order_by('urut', 'asc');
		$query = $this->db->get();
		return $query;
	}

	function data_system(){
		$this->db->select('*');
		$this->db->from($this->table);	
		$this->db->where('active', 1);
		$this->db->where('parent_menu_id', 4);
		$this->db->order_by('urut', 'asc');
		$query = $this->db->get();
		return $query;
	}
	
	function update_data($where, $data){		
		$this->db->where($where);
		$this->db->update($this->table, $data);
	}
	
}