<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Profile extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('m_user');
	}

	function index()
	{

		$data['user'] = $this->m_user->data_by_id(array('id_user' => get_cookie('id_user')))->row();
		$data['content'] = 'v_profile';
		$this->load->view('v_main', $data);
	}

	function edit()
	{
		if ($this->input->post('proses')) {
			$new = $this->input->post('new');
			$renew = $this->input->post('renew');
			if ($new == $renew) {
				$id = $this->input->post('id_user');
				$data['username'] = $this->input->post('username');
				$data['phone_number'] = $this->input->post('phone_number');
				$data['password'] = md5($new);
				$data['modiby'] = get_cookie('id_user');
				$data['modion'] = date("Y-m-d H:i:s");
				$query = $this->m_user->update_data("id_user='$id'", $data);
				if (!$query) {
					echo "<script>alert('Data successfully saved');window.location.href='../home';</script>";
				} else {
					echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
				}
			} else {
				echo "<script>alert('Input ulang Password tidak sama, silakan di coba kembali');window.history.go(-1);</script>";
			}
		} else {
			$id = base64_decode($this->uri->segment(3));
			$data['password_kategori'] = $this->m_user_kategori->data_active()->result_array();
			$data['password'] = $this->m_user->data_by_id("id_password='$id'")->row();
			$data['content'] = 'v_password_edit';
			$this->load->view('v_main', $data);
		}
	}
}
