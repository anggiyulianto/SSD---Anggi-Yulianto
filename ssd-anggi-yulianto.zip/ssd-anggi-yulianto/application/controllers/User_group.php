<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_group extends CI_Controller {
	function __construct(){
		parent::__construct();
		if(get_cookie('status')!="loginuser"){
			redirect('login');
		}
		$this->load->model('m_user_group');
		$this->load->model('m_counter');
	}

	function index(){
			$data['user_group'] = $this->m_user_group->data()->result_array();
			$data['content'] = 'v_user_group';
			$this->load->view('v_main',$data);
	}

	function input(){
		if($this->input->post('proses')){
			error_reporting(0);
			$CounterCode = "UG";
			$counter = $this->m_counter->data_by_id(array('CounterCode' => $CounterCode))->row();
			if($counter==null){
				$data_counter = 1;
				$input_counter = $this->m_counter->input_data(array('CounterCode' => $CounterCode, 'Counter' => $data_counter));
			}else{
				$data_counter = $counter->Counter+1;
				$update_counter = $this->m_counter->update_data(array('CounterCode' => $CounterCode), array('Counter' => $data_counter));
			}
			$data['kode_user_group'] = $CounterCode.str_pad($data_counter,4,"0",STR_PAD_LEFT);
			$data['nama_user_group'] = $this->input->post('nama_user_group');
			$menu = $this->input->post('menu');
			$all_menu = implode(',', $menu);
			$data['menu'] = $all_menu;
			$data['active'] = $this->input->post('active');
			$data['addby'] = get_cookie('id_user');	
			$data['addon'] = date("Y-m-d H:i:s");
			$query = $this->m_user_group->input_data($data);
			if(!$query){
	    		echo "<script>alert('Data successfully saved');window.location.href='../user_group';</script>";
	    	}else{
	    		echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
	    	}		    
		}else{
			$data['menu_master'] = $this->m_menu->data_master()->result_array();
			$data['menu_transaksi'] = $this->m_menu->data_transaksi()->result_array();
			$data['menu_report'] = $this->m_menu->data_report()->result_array();
			$data['menu_system'] = $this->m_menu->data_system()->result_array();
			$data['content'] = 'v_user_group_input';
			$this->load->view('v_main',$data);
		}
	}

	function edit(){
		if($this->input->post('proses')){
			error_reporting(0);			
			$id = $this->input->post('id_user_group');
			$data['nama_user_group'] = $this->input->post('nama_user_group');
			$menu = $this->input->post('menu');
			$all_menu = implode(',', $menu);
			$data['menu'] = $all_menu;
			$data['active'] = $this->input->post('active');
			$data['modiby'] = get_cookie('id_user');
			$data['modion'] = date("Y-m-d H:i:s");
			$query = $this->m_user_group->update_data("id_user_group='$id'",$data);
			if(!$query){
	    		echo "<script>alert('Data successfully saved');window.location.href='../user_group';</script>";
	    	}else{
	    		echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
	    	}
		}else{
			$id = base64_decode($this->uri->segment(3));
			$data['user_group'] = $this->m_user_group->data_by_id("id_user_group='$id'")->row();
			$data['user_group_menu'] = explode(',', $data['user_group']->menu);
			$data['menu_master'] = $this->m_menu->data_master()->result_array();
			$data['menu_transaksi'] = $this->m_menu->data_transaksi()->result_array();
			$data['menu_report'] = $this->m_menu->data_report()->result_array();
			$data['menu_system'] = $this->m_menu->data_system()->result_array();
			$data['content'] = 'v_user_group_edit';
			$this->load->view('v_main',$data);
		}
	}

	function delete(){
		if(get_cookie('status') != "loginuser"){
			redirect('login');
		}
		
		$id = base64_decode($this->uri->segment(3));
		$data['deleted'] = 1;
		$data['deleteby'] = get_cookie('id_user');	
		$data['deleteon'] = date("Y-m-d H:i:s");		
		$query = $this->m_user_group->hapus_data("id_user_group='$id'", $data);
		if(!$query){
		        echo "<script>alert('Deleted successfully saved');window.location.href='../../user_group';</script>";
    	}else{
    		echo "<script>alert('Data failed to delete');window.history.go(-1);</script>";
    	}
	}

	function active(){
		
		if(get_cookie('status') != "loginuser"){
			redirect('login');
		}
		if($this->uri->segment(3) == null){
			redirect('user_group');
		}else{
			$id = base64_decode($this->uri->segment(3));
			if($this->uri->segment(4)==1){
				$data['active'] = 0;
			}else{
				$data['active'] = 1;
			}
			$data['modiby'] = get_cookie('id_user');
			$data['modion'] = date("Y-m-d H:i:s");
			$query = $this->m_user_group->update_data("id_user_group='".$id."'",$data);
			if(!$query){
		        echo "<script>alert('Data successfully saved');window.location.href='../../../user_group';</script>";
	    	}else{
	    		echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
	    	}
		}
	}
}