<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends CI_Controller {
	function __construct(){
		parent::__construct();
		if(get_cookie('status')!="loginuser"){
			redirect('login');
		}
		$this->load->model('m_setting');
	}

	function index(){
		if($this->input->post('proses')){
			$data['nama_program'] = $this->input->post('nama_program');
			$data['color_program'] = $this->input->post('color_program');
			$data['modiby'] = get_cookie('id_user');
			$data['modion'] = date("Y-m-d H:i:s");
			$query = $this->m_setting->update_data($data);
			if(!$query){
	    		echo "<script>alert('Data successfully saved');window.location.href='../setting';</script>";
	    	}else{
	    		echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
	    	}
		}else{
			$data['setting'] = $this->m_setting->data();
			$data['content'] = 'v_setting';
			$this->load->view('v_main', $data);
		}	
	}
}