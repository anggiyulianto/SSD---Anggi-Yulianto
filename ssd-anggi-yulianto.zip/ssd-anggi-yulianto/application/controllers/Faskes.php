<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Faskes extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		if (get_cookie('status') != "loginuser") {
			redirect('login');
		}
		$this->load->model('m_faskes');
		$this->load->model('m_counter');
	}

	function index()
	{
		$data['faskes'] = $this->m_faskes->data()->result_array();
		$data['content'] = 'v_faskes';
		$this->load->view('v_main', $data);
	}

	function input()
	{
		if ($this->input->post('proses')) {
			$nomor_telpon = $this->input->post('nomor_telpon');
			$validator = $this->m_faskes->data_by_id(array('nomor_telpon' => $nomor_telpon, 'deleted' => 0))->row();
			if ($validator != null) {
				echo "<script>alert('nomor telpon sudah terdaftar');window.history.go(-1);</script>";
				die;
			} else {
				$data['nama_faskes'] = $this->input->post('nama_faskes');
				$data['alamat'] = $this->input->post('alamat');
				$data['nomor_telpon'] = $this->input->post('nomor_telpon');
				$data['latitude'] = $this->input->post('latitude');
				$data['longitude'] = $this->input->post('longitude');
				$data['active'] = $this->input->post('active');
				$data['addby'] = get_cookie('id_user');
				$data['addon'] = date("Y-m-d H:i:s");
				$query = $this->m_faskes->input_data($data);
				if (!$query) {
					echo "<script>alert('Data successfully saved');window.location.href='../faskes';</script>";
				} else {
					echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
				}
			}
		} else {
			$data['content'] = 'v_faskes_input';
			$this->load->view('v_main', $data);
		}
	}

	function edit()
	{
		if ($this->input->post('proses')) {
			$id = $this->input->post('id_faskes');
			$nomor_telpon = $this->input->post('nomor_telpon');
			$validator = $this->m_faskes->data_by_id(array('nomor_telpon' => $nomor_telpon, 'deleted' => 0, 'id_faskes != ' => $id))->row();
			if ($validator != null) {
				echo "<script>alert('nomor telpon sudah ada terdaftar');window.history.go(-1);</script>";
				die;
			} else {
				$data['nama_faskes'] = $this->input->post('nama_faskes');
				$data['alamat'] = $this->input->post('alamat');
				$data['nomor_telpon'] = $this->input->post('nomor_telpon');
				$data['latitude'] = $this->input->post('latitude');
				$data['longitude'] = $this->input->post('longitude');
				$data['active'] = $this->input->post('active');
				$data['modiby'] = get_cookie('id_user');
				$data['modion'] = date("Y-m-d H:i:s");
				$query = $this->m_faskes->update_data(array('id_faskes' => $id), $data);
				if (!$query) {
					echo "<script>alert('Data successfully updated');window.location.href='../faskes';</script>";
				} else {
					echo "<script>alert('Data failed to update, try again');window.history.go(-1);</script>";
				}
			}
		} else {
			$id = base64_decode($this->uri->segment(3));
			$data['faskes'] = $this->m_faskes->data_by_id(array('id_faskes' => $id))->row();
			$data['content'] = 'v_faskes_edit';
			$this->load->view('v_main', $data);
		}
	}

	function delete()
	{

		$id = base64_decode($this->uri->segment(3));
		$data['deleted'] = 1;
		$data['deleteby'] = get_cookie('id_user');
		$data['deleteon'] = date("Y-m-d H:i:s");
		$query = $this->m_faskes->hapus_data(array('id_faskes' => $id), $data);
		if (!$query) {
			echo "<script>alert('Data successfully deleted');window.location.href='../../faskes';</script>";
		} else {
			echo "<script>alert('Data failed to delete');window.history.go(-1);</script>";
		}
	}

	function active()
	{

		if ($this->uri->segment(3) == null) {
			redirect('faskes');
		} else {
			$id = base64_decode($this->uri->segment(3));
			if ($this->uri->segment(4) == 1) {
				$data['active'] = 0;
			} else {
				$data['active'] = 1;
			}
			$data['modiby'] = get_cookie('id_user');
			$data['modion'] = date("Y-m-d H:i:s");
			$query = $this->m_faskes->update_data(array('id_faskes' => $id), $data);
			if (!$query) {
				echo "<script>alert('Data successfully actived');window.location.href='../../../faskes';</script>";
			} else {
				echo "<script>alert('Data failed to active, try again');window.history.go(-1);</script>";
			}
		}
	}
}
