<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {
	function __construct(){
		parent::__construct();
		if(get_cookie('status')!="loginuser"){
			redirect('login');
		}
		$this->load->model('m_menu');
		$this->load->model('m_counter');
	}

	function index(){
		$data['menu'] = $this->m_menu->data()->result_array();
		$data['content'] = 'v_menu';
		$this->load->view('v_main',$data);
	}

	function input(){
		if($this->input->post('proses')){
			
			$CounterCode = "PK";
			$counter = $this->m_counter->data_by_id(array('CounterCode' => $CounterCode))->row();
			if($counter==null){
				$data_counter = 1;
				$input_counter = $this->m_counter->input_data(array('CounterCode' => $CounterCode, 'Counter' => $data_counter));
			}else{
				$data_counter = $counter->Counter+1;
				$update_counter = $this->m_counter->update_data(array('CounterCode' => $CounterCode), array('Counter' => $data_counter));
			}
			$data['kode_kategori'] = $CounterCode.str_pad($data_counter,3,"0",STR_PAD_LEFT);
			$data['nama_kategori'] = $this->input->post('nama_kategori');
			$data['active'] = $this->input->post('active');
			$data['addby'] = get_cookie('id_user');	
			$data['addon'] = date("Y-m-d H:i:s");
			$query = $this->m_menu->input_data($data);
			if(!$query){
	    		echo "<script>alert('Data successfully saved');window.location.href='../menu';</script>";
	    	}else{
	    		echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
	    	}		    
		}else{
			$data['content'] = 'v_menu_input';
			$this->load->view('v_main',$data);
		}
	}

	function edit(){
		if($this->input->post('proses')){
			
			$id = $this->input->post('id_menu');
			$parent_menu_id = $this->input->post('parent_menu_id');
			$data['parent_menu_id'] = $parent_menu_id;
			$data['parent_nama'] = ($parent_menu_id == 1 ? 'MASTER DATA' : ($parent_menu_id == 2 ? 'TRANSAKSI' : ($parent_menu_id == 3 ? 'REPORT' : '')));
			$data['urut'] = $this->input->post('urut');
			$data['nama_menu'] = $this->input->post('nama_menu');
			$data['active'] = $this->input->post('active');
			$data['modiby'] = get_cookie('id_user');
			$data['modion'] = date("Y-m-d H:i:s");
			$query = $this->m_menu->update_data("id_menu='$id'",$data);
			if(!$query){
	    		echo "<script>alert('Data successfully saved');window.location.href='../menu';</script>";
	    	}else{
	    		echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
	    	}
		}else{
			$id = base64_decode($this->uri->segment(3));
			$data['menu'] = $this->m_menu->data_by_id("id_menu='$id'")->row();
			$data['content'] = 'v_menu_edit';
			$this->load->view('v_main',$data);
		}
	}

	function delete(){
		
		$id = base64_decode($this->uri->segment(3));
		$data['deleted'] = 1;
		$data['deleteby'] = get_cookie('id_user');	
		$data['deleteon'] = date("Y-m-d H:i:s");		
		$query = $this->m_menu->hapus_data("id_menu='$id'", $data);
		if(!$query){
		        echo "<script>alert('Data successfully saved');window.location.href='../../menu';</script>";
    	}else{
    		echo "<script>alert('Data failed to delete');window.history.go(-1);</script>";
    	}
	}

	function active(){
		
		if($this->uri->segment(3) == null){
			redirect('menu');
		}else{
			$id = base64_decode($this->uri->segment(3));
			if($this->uri->segment(4)==1){
				$data['active'] = 0;
			}else{
				$data['active'] = 1;
			}
			$data['modiby'] = get_cookie('id_user');
			$data['modion'] = date("Y-m-d H:i:s");
			$query = $this->m_menu->update_data("id_menu='".$id."'",$data);
			if(!$query){
		        echo "<script>alert('Data successfully saved');window.location.href='../../../menu';</script>";
	    	}else{
	    		echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
	    	}
		}
	}
}