<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('m_setting');
		$this->load->model('m_login');
		$this->load->model('m_user');
	}

	function index()
	{
		if (get_cookie('status') == "loginuser") {
			redirect('home');
		} else {
			$data['setting'] = $this->m_setting->data();
			$this->load->view('v_login', $data);
		}
	}

	function login()
	{
		$login = FALSE;
		$k = substr(date("d"), -1) . substr(date("m"), -1) . substr(date("y"), -1) . "106";
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$data['username'] = $username;
		$data['password'] = md5($password);
		$datalogin = $this->m_login->loginuser($data)->row();
		$jdatalogin = $this->m_login->loginuser($data)->num_rows();
		if ($jdatalogin > 0) {
			if ($datalogin->active == 1) {
				$this->input->set_cookie(array('name' => 'id_user', 'value' => $datalogin->id_user, 'expire' => 3600 * 18));
				$this->input->set_cookie(array('name' => 'username', 'value' => $datalogin->username, 'expire' => 3600 * 18));
				$this->input->set_cookie(array('name' => 'status', 'value' => "loginuser", 'expire' => 3600 * 18));
				redirect('home');
			} else {
				echo "<script>alert('User Not Active !!');window.location.href='../login';</script>";
			}
		} else {
			echo "<script>alert('Username / Password Invalid !!');window.location.href='../login';</script>";
		}
	}

	function logout()
	{
		delete_cookie('id_user');
		delete_cookie('username');
		delete_cookie('status');
		redirect('login');
	}

	function register()
	{
		if ($this->input->post('proses')) {
			$password = $this->input->post('password');
			$password2 = $this->input->post('password2');
			$username = $this->input->post('username');
			if ($password == $password2) {
				$data_user = $this->m_user->data_by_id("username='$username'")->num_rows();
				if ($data_user == 0) {
					$data['id_user_group'] = 2;
					$data['username'] = $username;
					$data['phone_number'] = $this->input->post('phone_number');
					$data['password'] = md5($password);
					$data['active'] = 1;
					$data['addby'] = 99;
					$data['addon'] = date("Y-m-d H:i:s");
					$query = $this->m_user->input_data($data);
					if (!$query) {
						echo "<script>alert('Data successfully saved');window.location.href='../login';</script>";
					} else {
						echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
					}
				} else {
					echo "<script>alert('Username sudah terdaftar');window.history.go(-1);</script>";
				}
			} else {
				echo "<script>alert('Password tidak sama');window.history.go(-1);</script>";
			}
		} else {
			if (get_cookie('status') == "loginuser") {
				redirect('home');
			} else {
				$data['setting'] = $this->m_setting->data();
				$this->load->view('v_register', $data);
			}
		}
	}
}
