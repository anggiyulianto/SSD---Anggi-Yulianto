<?php
defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/jwt/vendor/autoload.php';

use \Firebase\JWT\JWT;

class Api extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		date_default_timezone_set('Asia/Jakarta');
	}

	function index()
	{
		header("Content-Type: application/json");
		$response['message'] = "access_denied";
		echo json_encode($response);
	}

	function token()
	{
		$config = file_get_contents(APPPATH . 'libraries/jwt/config.json');
		$config = json_decode($config);
		$response = [];
		$response = NULL;

		if ($_SERVER['REQUEST_METHOD'] === 'POST') {

			$val_client_id 		= '0e989d435d'; //substr(md5('4n99!.'),0,10);
			$val_client_secret 	= '1e94e4047bc1aa6e7ca077e65fcb47ab'; //md5('4n99!.Yul14nt0');

			$headers = apache_request_headers();

			$headerRequired = array('Authorization');
			foreach ($headerRequired as $key => $valparam) {
				if (!isset($headers[$valparam]) || $headers[$valparam] == "") {
					header("Content-Type: application/json");
					$response['message'] = "header " . $valparam . " required";
					echo json_encode($response);
					die;
				}
			}


			$authorization = $headers["Authorization"];
			$client = explode(" ", $authorization);
			if (sizeof($client) != 2) {
				header("Content-Type: application/json");
				$response['message'] = "invalid Authorization";
				echo json_encode($response);
				die;
			}

			$client_id_secret = base64_decode($client[1]);
			$client = explode(":", $client_id_secret);
			if (sizeof($client) != 2) {
				header("Content-Type: application/json");
				$response['message'] = "invalid Authorization";
				echo json_encode($response);
				die;
			}
			$client_id = $client[0];
			$client_secret = $client[1];

			if ($val_client_id == $client_id && $val_client_secret == $client_secret) {
				$jwtPayload = [
					'username' => $client_id_secret,
					'iat' => time(),
					'exp' => time() + $config->jwt_token_lifetime
				];
				$jwt = JWT::encode($jwtPayload, $config->jwt_secret);
				$response['access_token'] = $jwt;
				$response['token_type'] = "bearer";
				$response['expires_in'] = $config->jwt_token_lifetime;
				$response['scope'] = "resource.WRITE resource.READ";
			} else {
				$response['message'] = "unauthorized_client";
			}
		} else {
			$response['message'] = "access_denied";
		}

		echo json_encode($response);
	}

	function getfaskes()
	{
		$config = file_get_contents(APPPATH . 'libraries/jwt/config.json');
		$config = json_decode($config);
		$response = NULL;
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$headers = $this->input->request_headers();
			$param = json_decode(file_get_contents('php://input'));

			$filter = NULL;
			if (isset($param->nama_faskes)) {
				$filter = array('nama_faskes' => $param->nama_faskes);
			}

			try {
				$token = $headers['Authorization'];
				$decoded = JWT::decode($token, $config->jwt_secret, (array)$config->jwt_signing_alg);
			} catch (\Exception $e) {
				$response['message'] = ($e->getMessage() == 'Expired token' ? 'expired token' : 'invalid token');
				echo json_encode($response);
				die;
			}
			$this->db->select('`nama_faskes`, `alamat`, `nomor_telpon`, `latitude`, `longitude`');
			$this->db->from('tbl_faskes');
			$this->db->where('deleted', 0);
			$this->db->where('active', 1);
			if (!empty($filter)) {
				$this->db->like($filter);
			}
			$data = json_encode($this->db->get()->result_array());
			echo $data;
		} else {
			$response['message'] = "access_denied";
			echo json_encode($response);
		}
	}
	function get_kelurahan()
	{
		$curl = curl_init();

		curl_setopt_array($curl, array(
			CURLOPT_URL => 'http://api.jakarta.go.id/v1/kelurahan/?format=geojson',
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'GET',
			CURLOPT_HTTPHEADER => array(
				'Authorization: v3pP0k7wzdvXvNYUrFBJ/vA+bvBaAUn70uwSivWVXwmr+HT8p5BZ7mO0O/G1dzxv'
			),
		));

		$response = curl_exec($curl);
		curl_close($curl);

		// if (!file_exists(base_url('assets/kelurahan.json'))) {
		// 	return json_decode(file_get_contents(base_url('assets/kelurahan.json')));
		// } else {
		// 	return $response;
		// }

		if (empty($response)) {
			echo json_decode(file_get_contents(base_url('assets/kelurahan.json')));
		} else {
			echo $response;
		}
	}

	function get_maps()
	{
		$this->load->model('m_faskes');
		$data['faskes'] = $this->m_faskes->data()->result_array();
		$this->load->view('v_mapsall', $data);
	}

	function get_maps2()
	{
		$this->load->model('m_faskes');
		$data['faskes'] = $this->m_faskes->data()->result_array();
		$this->load->view('v_maps2', $data);
	}
}
