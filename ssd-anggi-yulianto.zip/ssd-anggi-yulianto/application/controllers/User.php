<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		if (get_cookie('status') != "loginuser") {
			redirect('login');
		}
		$this->load->model('m_user');
		$this->load->model('m_user_group');
		$this->load->model('m_counter');
	}

	function index()
	{
		$data['user'] = $this->m_user->data()->result_array();
		$data['content'] = 'v_user';
		$this->load->view('v_main', $data);
	}

	function input()
	{
		if ($this->input->post('proses')) {
			$password = $this->input->post('password');
			$password2 = $this->input->post('password2');
			$username = $this->input->post('username');
			if ($password == $password2) {
				$data_user = $this->m_user->data_by_id("username='$username'")->num_rows();
				if ($data_user == 0) {
					$data['id_user_group'] = $this->input->post('id_user_group');
					$data['username'] = $username;
					$data['password'] = md5($password);
					$data['active'] = $this->input->post('active');
					$data['addby'] = get_cookie('id_user');
					$data['addon'] = date("Y-m-d H:i:s");
					$query = $this->m_user->input_data($data);
					if (!$query) {
						echo "<script>alert('Data successfully saved');window.location.href='../user';</script>";
					} else {
						echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
					}
				} else {
					echo "<script>alert('Username sudah terdaftar');window.history.go(-1);</script>";
				}
			} else {
				echo "<script>alert('Password tidak sama');window.history.go(-1);</script>";
			}
		} else {
			$data['user_group'] = $this->m_user_group->data_active()->result_array();
			$data['content'] = 'v_user_input';
			$this->load->view('v_main', $data);
		}
	}

	function password()
	{
		if ($this->input->post('proses')) {
			$id_user = $this->input->post('id_user');
			$current = $this->input->post('current');
			$valid = array('id_user' => $id_user, 'password' => md5($current));
			$data_user = $this->m_user->data_by_id($valid)->row();
			if ($data_user == null) {
				echo "<script>alert('Password lama anda salah, silakan di coba kembali');window.history.go(-1);</script>";
			} else {
				$new = $this->input->post('new');
				$renew = $this->input->post('renew');
				if ($new == $renew) {
					$data['password'] = md5($new);
					$data['modiby'] = get_cookie('id_user');
					$data['modion'] = date("Y-m-d H:i:s");
					$query = $this->m_user->update_data("id_user='$id_user'", $data);
					if (!$query) {
						delete_cookie('id_user');
						delete_cookie('username');
						delete_cookie('status');
						echo "<script>alert('Data successfully saved');window.location.href='../login';</script>";
					} else {
						echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
					}
				} else {
					echo "<script>alert('Input ulang Password tidak sama, silakan di coba kembali');window.history.go(-1);</script>";
				}
			}
		} else {
			$data['user_group'] = $this->m_user_group->data_active()->result_array();
			$data['content'] = 'v_user_password';
			$this->load->view('v_main', $data);
		}
	}

	function edit()
	{
		if ($this->input->post('proses')) {

			$id = $this->input->post('id_user');
			$data['id_user_group'] = $this->input->post('id_user_group');
			$data['username'] = $this->input->post('username');
			$data['active'] = $this->input->post('active');
			$data['modiby'] = get_cookie('id_user');
			$data['modion'] = date("Y-m-d H:i:s");
			$query = $this->m_user->update_data("id_user='$id'", $data);
			if (!$query) {
				echo "<script>alert('Data successfully saved');window.location.href='../user';</script>";
			} else {
				echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
			}
		} else {
			$id = base64_decode($this->uri->segment(3));

			$data['user_group'] = $this->m_user_group->data_active()->result_array();
			$data['user'] = $this->m_user->data_by_id("id_user='$id'")->row();
			$data['content'] = 'v_user_edit';
			$this->load->view('v_main', $data);
		}
	}

	function delete()
	{

		$id = base64_decode($this->uri->segment(3));
		$data['deleted'] = 1;
		$data['deleteby'] = get_cookie('id_user');
		$data['deleteon'] = date("Y-m-d H:i:s");
		$query = $this->m_user->hapus_data("id_user='$id'", $data);
		if (!$query) {
			echo "<script>alert('Deleted successfully saved');window.location.href='../../user';</script>";
		} else {
			echo "<script>alert('Data failed to delete');window.history.go(-1);</script>";
		}
	}

	function active()
	{

		if ($this->uri->segment(3) == null) {
			redirect('user');
		} else {
			$id = base64_decode($this->uri->segment(3));
			if ($this->uri->segment(4) == 1) {
				$data['active'] = 0;
			} else {
				$data['active'] = 1;
			}
			$data['modiby'] = get_cookie('id_user');
			$data['modion'] = date("Y-m-d H:i:s");
			$query = $this->m_user->update_data("id_user='" . $id . "'", $data);
			if (!$query) {
				echo "<script>alert('Data successfully saved');window.location.href='../../../user';</script>";
			} else {
				echo "<script>alert('Data failed to save, try again');window.history.go(-1);</script>";
			}
		}
	}
}
