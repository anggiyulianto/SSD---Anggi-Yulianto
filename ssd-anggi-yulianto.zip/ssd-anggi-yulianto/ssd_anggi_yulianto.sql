-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 27, 2021 at 08:06 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_counter`
--

CREATE TABLE `tbl_counter` (
  `CounterCode` varchar(30) NOT NULL,
  `Counter` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_counter`
--

INSERT INTO `tbl_counter` (`CounterCode`, `Counter`) VALUES
('UG', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faskes`
--

CREATE TABLE `tbl_faskes` (
  `id_faskes` int(12) NOT NULL,
  `nama_faskes` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `nomor_telpon` varchar(30) NOT NULL,
  `latitude` decimal(6,2) NOT NULL,
  `longitude` decimal(6,2) NOT NULL,
  `active` int(1) NOT NULL,
  `addby` int(12) NOT NULL,
  `addon` datetime NOT NULL,
  `modiby` int(12) NOT NULL,
  `modion` datetime NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  `deleteby` int(12) NOT NULL,
  `deleteon` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_faskes`
--

INSERT INTO `tbl_faskes` (`id_faskes`, `nama_faskes`, `alamat`, `nomor_telpon`, `latitude`, `longitude`, `active`, `addby`, `addon`, `modiby`, `modion`, `deleted`, `deleteby`, `deleteon`) VALUES
(1, 'Unit Test', 'Bekasi Barat', '02123', '-6.13', '106.80', 1, 1, '2021-01-26 20:14:19', 1, '2021-01-26 22:51:54', 0, 0, '0000-00-00 00:00:00'),
(2, 'unit test 2', 'Jakarta', '123', '-6.26', '106.93', 1, 1, '2021-01-26 22:48:14', 1, '2021-01-26 22:59:43', 0, 0, '0000-00-00 00:00:00'),
(3, 'unit test 3', 'DKI', '987', '-6.20', '106.81', 1, 1, '2021-01-26 22:48:47', 1, '2021-01-26 23:00:13', 0, 0, '0000-00-00 00:00:00'),
(4, 'unit test 4', 'Jakarta Barat', '654', '-6.18', '106.81', 1, 1, '2021-01-26 22:49:19', 1, '2021-01-26 23:00:39', 0, 0, '0000-00-00 00:00:00'),
(5, 'test 5', 'jakarta selatan', '876567', '-6.17', '106.86', 1, 1, '2021-01-26 23:47:12', 0, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `id_menu` int(11) NOT NULL,
  `parent_menu_id` int(12) NOT NULL,
  `parent_nama` varchar(100) NOT NULL,
  `nama_menu` varchar(150) NOT NULL,
  `controller` varchar(100) NOT NULL,
  `urut` int(10) NOT NULL,
  `active` int(1) NOT NULL,
  `modiby` int(12) NOT NULL,
  `modion` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`id_menu`, `parent_menu_id`, `parent_nama`, `nama_menu`, `controller`, `urut`, `active`, `modiby`, `modion`) VALUES
(1, 1, 'MASTER DATA', 'Faskes', 'faskes', 1, 1, 1, '2021-01-26 23:25:01'),
(2, 4, 'SYSTEM', 'User Group', 'user_group', 5000, 1, 0, '0000-00-00 00:00:00'),
(3, 4, 'SYSTEM', 'User', 'user', 6000, 1, 0, '0000-00-00 00:00:00'),
(4, 4, 'SYSTEM', 'Menu', 'menu', 8000, 1, 1, '2019-03-16 13:40:12'),
(5, 4, 'SYSTEM', 'Setting', 'setting', 9999, 1, 1, '2019-03-26 13:01:54'),
(6, 4, 'SYSTEM', 'Profile', 'profile', 1000, 1, 1, '2021-01-26 23:29:06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_setting`
--

CREATE TABLE `tbl_setting` (
  `id_setting` int(1) NOT NULL,
  `nama_program` varchar(200) NOT NULL,
  `color_program` varchar(10) NOT NULL,
  `modiby` int(11) NOT NULL,
  `modion` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_setting`
--

INSERT INTO `tbl_setting` (`id_setting`, `nama_program`, `color_program`, `modiby`, `modion`) VALUES
(0, 'SSD - ANGGI YULIANTO', '4169E1', 1, '2021-01-26 20:27:23');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(12) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone_number` varchar(30) NOT NULL,
  `id_user_group` varchar(200) NOT NULL,
  `active` int(1) NOT NULL,
  `addby` int(12) NOT NULL,
  `addon` datetime NOT NULL,
  `modiby` int(12) NOT NULL,
  `modion` datetime NOT NULL,
  `deleted` int(1) NOT NULL,
  `deleteby` int(12) NOT NULL,
  `deleteon` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `password`, `phone_number`, `id_user_group`, `active`, `addby`, `addon`, `modiby`, `modion`, `deleted`, `deleteby`, `deleteon`) VALUES
(1, 'ADMINISTRATOR', 'eb0a191797624dd3a48fa681d3061212', '', '1', 1, 0, '2017-11-13 13:54:00', 1, '2019-12-02 11:23:26', 0, 0, '0000-00-00 00:00:00'),
(2, 'ssd_anggi', '7e1c0f1e879990b0ad71d41b3984a08c', '12345', '2', 1, 99, '2021-01-26 23:48:08', 0, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_group`
--

CREATE TABLE `tbl_user_group` (
  `id_user_group` int(12) NOT NULL,
  `kode_user_group` varchar(12) NOT NULL,
  `nama_user_group` varchar(200) NOT NULL,
  `menu` varchar(200) DEFAULT NULL,
  `active` int(1) NOT NULL,
  `addby` int(12) NOT NULL,
  `addon` datetime NOT NULL,
  `modiby` int(12) NOT NULL,
  `modion` datetime NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  `deleteby` int(12) NOT NULL,
  `deleteon` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_group`
--

INSERT INTO `tbl_user_group` (`id_user_group`, `kode_user_group`, `nama_user_group`, `menu`, `active`, `addby`, `addon`, `modiby`, `modion`, `deleted`, `deleteby`, `deleteon`) VALUES
(1, 'UG0001', 'ADMINISTRATOR', '1,6,2,3,4,5', 1, 1, '2019-03-01 14:09:41', 1, '2021-01-26 19:52:29', 0, 0, '0000-00-00 00:00:00'),
(2, 'UG0002', 'USER', '1,6', 1, 1, '2019-09-12 22:59:07', 1, '2021-01-26 19:52:36', 0, 0, '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_counter`
--
ALTER TABLE `tbl_counter`
  ADD PRIMARY KEY (`CounterCode`);

--
-- Indexes for table `tbl_faskes`
--
ALTER TABLE `tbl_faskes`
  ADD PRIMARY KEY (`id_faskes`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`id_menu`);

--
-- Indexes for table `tbl_setting`
--
ALTER TABLE `tbl_setting`
  ADD PRIMARY KEY (`id_setting`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `tbl_user_group`
--
ALTER TABLE `tbl_user_group`
  ADD PRIMARY KEY (`id_user_group`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_faskes`
--
ALTER TABLE `tbl_faskes`
  MODIFY `id_faskes` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_user_group`
--
ALTER TABLE `tbl_user_group`
  MODIFY `id_user_group` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
